﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Library.Admin.Startup))]
namespace Library.Admin
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
